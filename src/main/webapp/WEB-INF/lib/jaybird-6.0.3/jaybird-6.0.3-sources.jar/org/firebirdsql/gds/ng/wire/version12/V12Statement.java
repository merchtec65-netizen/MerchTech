/*
 * Firebird Open Source JDBC Driver
 *
 * Distributable under LGPL license.
 * You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * LGPL License for more details.
 *
 * This file was created by members of the firebird development team.
 * All individual contributions remain the Copyright (C) of those
 * individuals.  Contributors to this file are either listed here or
 * can be obtained from a source control history command.
 *
 * All rights reserved.
 */
package org.firebirdsql.gds.ng.wire.version12;

import org.firebirdsql.gds.ng.wire.FbWireDatabase;
import org.firebirdsql.gds.ng.wire.version11.V11Statement;

/**
 * @author Mark Rotteveel
 */
public class V12Statement extends V11Statement {

    /**
     * Creates a new instance of V12Statement for the specified database.
     *
     * @param database
     *         FbWireDatabase implementation
     */
    public V12Statement(FbWireDatabase database) {
        super(database);
    }

    @Override
    public int getMaxSqlInfoSize() {
        // Theoretically, also protocol 11 (Firebird 2.1), but not supported since before Jaybird 5
        return 65535;
    }

}
